A Pen created at CodePen.io. You can find this one at https://codepen.io/Fafnir/pen/eLbmoj.

 A dice game of chance in JavaScript.  A player must reach the score of 100 by accumulating points each turn, player must avoid rolling a 1 or he/she will lose all points for that round. You play choose to "hold" and end your turn to keep your current points before risking rolling a 1.